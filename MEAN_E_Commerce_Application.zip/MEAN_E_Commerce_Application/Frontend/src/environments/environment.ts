export const environment = {
    apiUrl:"http://myshop.test"
};

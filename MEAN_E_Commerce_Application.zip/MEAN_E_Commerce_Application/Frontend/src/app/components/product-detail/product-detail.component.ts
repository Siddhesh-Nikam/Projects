import { Component, inject } from '@angular/core';
import { CustomerService } from '../../services/customer.service';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../../types/product';
import { WishlistService } from '../../services/wishlist.service';
import { MatButtonModule } from '@angular/material/button';
import { ProductCardComponent } from '../product-card/product-card.component';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [MatButtonModule,ProductCardComponent,MatIconModule],
  templateUrl: './product-detail.component.html',
  styleUrl: './product-detail.component.scss'
})
export class ProductDetailComponent {

  customerService=inject(CustomerService);
  route=inject(ActivatedRoute);
  product!:Product;

  ngOnInit(){
    const id = this.route.snapshot.params["id"];
    this.customerService.getProductById(id).subscribe(result=>{
      this.product=result;
      console.log(this.product);
    })
  }

  get sellingPrice(){
    return this.product.Price - (this.product.Price * this.product.discount)/100 
  }

  wishlistService=inject(WishlistService);

  addToWishList(product:Product){
    console.log(product);
    if(this.isInWishlist(product)){
      this.wishlistService
      .removeFromWishlists(product._id!)
      .subscribe((result)=>{
        this.wishlistService.init();
      });
    } else {
      this.wishlistService
      .addInWishlist(product._id!)
      .subscribe((result)=>{
        this.wishlistService.init();
      });
    }

  }

  isInWishlist(product:Product){
    let isExists = this.wishlistService.wishlists.find(
      (x) => x._id == product._id
    );

    if(isExists) return true;
    else return false;

  }


}
